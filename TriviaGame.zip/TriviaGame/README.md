# TriviaGame

 
#  Game in started by pressing the start button
#  Once pressed, button disapears and reloads the page with the following changes
    #  A countdown timer is initiated.
    #  MCQs will appear on the page with four answers per each question and radio buttons to select answer
    #  Once all the questions are answered and press "done" button or if the countdown timer goes to zero page is reloaded with the following changes
        # numnber of questions answered correctly
        # number of questions answered incorrectly
        # number of unanswered questions
## can only provide one answer per question.

# first create an OnClick function to start the game
# The rest of the code is encapsulated inside thsi onclick function.
